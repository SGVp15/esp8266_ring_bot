// ---------------------------------------------------------------
// --- INCLUDE --- INCLUDE --- INCLUDE --- INCLUDE --- INCLUDE ---
// ---------------------------------------------------------------
#include <ESP8266WiFi.h>        // Содержится в пакете. Видео с уроком http://esp8266-arduinoide.ru/step1-wifi
#include <ESP8266WebServer.h>   // Содержится в пакете. Видео с уроком http://esp8266-arduinoide.ru/step2-webserver
#include <ESP8266SSDP.h>        // Содержится в пакете. Видео с уроком http://esp8266-arduinoide.ru/step3-ssdp
#include <FS.h>                 // Содержится в пакете. Видео с уроком http://esp8266-arduinoide.ru/step4-fswebserver
#include <ArduinoJson.h>        // Установить из менеджера библиотек.

#include <ESP8266HTTPUpdateServer.h>  // Содержится в пакете.

#include <UniversalTelegramBot.h>
#include <WiFiClientSecure.h>

#include <ArduinoOTA.h>         // Прошивка по WIFI
#include <ESP8266mDNS.h>
#include <WIFIUdp.h>

//#include <LibPrintf.h>


#define len(x) sizeof(x) / sizeof(x[0])
// ---------------------------------------------------------------
// --- Debug --- Debug --- Debug --- Debug --- Debug --- Debug ---
// ---------------------------------------------------------------



// Объект для обновления с web страницы
ESP8266HTTPUpdateServer httpUpdater;

// Web интерфейс для устройства
ESP8266WebServer HTTP;

// ---------------------------------------------------------------
// --- HTTP pass --- HTTP pass --- HTTP pass --- HTTP pass --- HTT
// ---------------------------------------------------------------
const char* www_username = "admin";
const char* www_password = "esp8266";


// Для файловой системы
File fsUploadFile;


// ---------------------------------------------------------------
// --- Определяем переменные wifi --- Определяем переменные wifi -
// ---------------------------------------------------------------
String ssid;       // = "n5";              // Для хранения SSID
String password_wifi;   // = "1234567890";      // Для хранения пароля сети
String ssidAP;     // = "ESP-8266-ring";   // SSID AP точки доступа
String password_AP; // = "1234567890";      // пароль точки доступа
String SSDP_Name;   // = "Update-Time";     // Имя SSDP
bool is_AP_mode = true;                    // Статус wifi точки, по ней проверяем в каком статусе WIFI модуль
const unsigned long wifi_ap_timeout = 300 * 1000;  // Время мс, через которое esp пытается подключится к wifi (5 минут)
int timezone;       // = 3;                 // часовой пояс GTM

// ---------------------------------------------------------------
// --- Config --- Config --- Config --- Config --- Config --- Conf
// ---------------------------------------------------------------
String jsonConfig = "/config.json";
String log_file = "/log.txt";
int port = 80;
bool is_http_enable = true;
// ---------------------------------------------------------------
// --- Pins --- Pins --- Pins --- Pins --- Pins --- Pins --- Pins 
// ---------------------------------------------------------------
#define LED_PIN D4   // Светодиод
#define RING_PIN D2  // Кнопка
volatile bool status_ring_button = false;
void ICACHE_RAM_ATTR ring() {
  status_ring_button = true;
}

// ---------------------------------------------------------------
// --- ArduinoOTA --- ArduinoOTA --- ArduinoOTA --- ArduinoOTA ---
// ---------------------------------------------------------------
#define OTAUSER         "admin"    // Логин для входа в OTA
#define OTAPASSWORD     "qweasdqwe"    // Пароль для входа в ОТА

// ---------------------------------------------------------------
// --- Telegram --- Telegram --- Telegram --- Telegram --- Telegra
// ---------------------------------------------------------------
String BOT_TOKEN;   // = "5155216886:AAF51QDjtFoM5A3sXH7WTdKO1WBjpMR4kn8";
String CHAT_ID;     // = "822072027";  // https://api.telegram.org/bot5155216886:AAF51QDjtFoM5A3sXH7WTdKO1WBjpMR4kn8/getUpdates

bool state_notification = true;  // уведомление

unsigned long bot_timeout = 10 * 1000;  // Время мс, через которое бот проверяет новые сообщения

X509List cert(TELEGRAM_CERTIFICATE_ROOT);

WiFiClientSecure secured_client;
UniversalTelegramBot bot(BOT_TOKEN, secured_client);
